trigger ContactTrigger on Contact (after insert) {
    List<Property_Owner__c> owners = new List<Property_Owner__c>();
    for(Contact c : Trigger.new) {
        Property_Owner__c o = new Property_Owner__c();
        o.Name          = (c.FirstName != null ? c.FirstName : '') + ' ' + c.LastName;
        o.Email_Id__c   = c.Email;
        o.Mobile__c     = c.MobilePhone;
        o.Owner_Type__c = 'Individual';
        o.Contact__c    = c.Id;
        o.Active__c     = false;
        owners.add(o);
    }
    if(!owners.isEmpty()) insert owners;
}
