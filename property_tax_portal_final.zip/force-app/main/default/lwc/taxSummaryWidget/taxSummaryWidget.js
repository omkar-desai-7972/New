import { LightningElement, track, wire } from 'lwc';
import getDashboardSummary from '@salesforce/apex/PropertyOwnerDashboardController.getDashboardSummary';
import getMyProperties     from '@salesforce/apex/PropertyOwnerDashboardController.getMyProperties';

const MAX_ROWS = 4;

export default class TaxSummaryWidget extends LightningElement {

    @track summary      = {};
    @track assessments  = [];
    @track isLoading    = true;
    @track isLoaded     = false;

    @wire(getDashboardSummary)
    wiredSummary({ data, error }) {
        if (data) {
            this.summary   = data;
            this.isLoading = false;
            this.isLoaded  = true;
        } else if (error) {
            this.isLoading = false;
        }
    }

    @wire(getMyProperties, { statusFilter: 'Active', searchTerm: '' })
    wiredProperties({ data }) {
        if (data) {
            this.assessments = data
                .filter(p => p.assessmentId)
                .map(p => ({
                    id             : p.propertyId,
                    propertyName   : p.propertyName,
                    year           : p.assessmentYear,
                    amount         : p.annualTax,
                    formattedAmount: Number(p.annualTax || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 }),
                    status         : p.paymentStatus,
                    statusClass    : p.paymentStatus === 'Paid'
                        ? 'br-badge br-paid' : 'br-badge br-pending'
                }));
        }
    }

    get paidPercentage() {
        const total = (this.summary?.totalTaxDue || 0) + (this.summary?.totalTaxPaid || 0);
        if (!total) return 0;
        return Math.round((this.summary.totalTaxPaid / total) * 100);
    }

    get progressStyle() {
        return `width: ${this.paidPercentage}%`;
    }

    get formattedPaid() {
        return Number(this.summary?.totalTaxPaid || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 });
    }

    get formattedDue() {
        return Number(this.summary?.totalTaxDue || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 });
    }

    get assessmentRows() {
        return this.assessments.slice(0, MAX_ROWS);
    }

    get hasMore() {
        return this.assessments.length > MAX_ROWS;
    }

    get remainingCount() {
        return this.assessments.length - MAX_ROWS;
    }

    handleViewAll() {
        this.dispatchEvent(new CustomEvent('viewall', { bubbles: true, composed: true }));
    }
}
