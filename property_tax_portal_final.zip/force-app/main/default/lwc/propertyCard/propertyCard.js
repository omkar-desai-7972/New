import { LightningElement, api } from 'lwc';

const TYPE_ICONS = {
    'Individual House'    : '🏠',
    'Apartment'           : '🏢',
    'Commercial Complex'  : '🏬',
    'Government Building' : '🏛️',
};

const STATUS_RIBBON = {
    'Active'               : 'ribbon ribbon-active',
    'Pending Clerk Review' : 'ribbon ribbon-pending',
    'Pending Tax Officer'  : 'ribbon ribbon-pending',
    'Rejected'             : 'ribbon ribbon-rejected',
    'Inactive'             : 'ribbon ribbon-inactive',
    'Disputed'             : 'ribbon ribbon-disputed',
};

const PAYMENT_STATUS_CSS = {
    'Paid'    : 'pay-badge pay-paid',
    'Pending' : 'pay-badge pay-pending',
};

export default class PropertyCard extends LightningElement {

    @api property    = {};
    @api isSelected  = false;

    // ── Computed ──────────────────────────────────
    get cardClass() {
        return this.isSelected
            ? 'property-card property-card-selected'
            : 'property-card';
    }

    get typeIcon() {
        return TYPE_ICONS[this.property?.propertyType] || '🏠';
    }

    get statusRibbonClass() {
        return STATUS_RIBBON[this.property?.propertyStatus] || 'ribbon ribbon-inactive';
    }

    get hasAssessment() {
        return !!this.property?.assessmentId;
    }

    get canPay() {
        return this.property?.paymentStatus === 'Pending'
            && this.property?.propertyStatus === 'Active';
    }

    get formattedTax() {
        const val = this.property?.annualTax;
        if (val == null) return '—';
        return Number(val).toLocaleString('en-IN', { maximumFractionDigits: 0 });
    }

    get formattedDueDate() {
        const d = this.property?.taxDueDate;
        if (!d) return '—';
        return new Date(d).toLocaleDateString('en-IN', {
            day: '2-digit', month: 'short', year: 'numeric'
        });
    }

    get paymentStatusClass() {
        return PAYMENT_STATUS_CSS[this.property?.paymentStatus] || 'pay-badge pay-pending';
    }

    // ── Handlers ──────────────────────────────────
    handleCardClick() {
        this.dispatchEvent(new CustomEvent('propertyselect', {
            detail : { propertyId: this.property.propertyId },
            bubbles: true, composed: true
        }));
    }

    handleViewDetails(event) {
        event.stopPropagation();
        // Navigate to record detail page
        this.dispatchEvent(new CustomEvent('propertyselect', {
            detail : { propertyId: this.property.propertyId, navigate: true },
            bubbles: true, composed: true
        }));
    }

    handleMakePayment(event) {
        event.stopPropagation();
        this.dispatchEvent(new CustomEvent('makepayment', {
            detail : {
                propertyId   : this.property.propertyId,
                assessmentId : this.property.assessmentId
            },
            bubbles: true, composed: true
        }));
    }
}
