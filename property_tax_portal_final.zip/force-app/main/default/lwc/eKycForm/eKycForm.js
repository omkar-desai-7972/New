import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent }               from 'lightning/platformShowToastEvent';
import { NavigationMixin }              from 'lightning/navigation';
import getOwnerProfile from '@salesforce/apex/EKycController.getOwnerProfile';
import saveKyc         from '@salesforce/apex/EKycController.saveKyc';

export default class EKycForm extends NavigationMixin(LightningElement) {

    @track currentStep  = 1;
    @track isSubmitting = false;
    @track errorMsg     = null;
    @track isKycDone    = false;
    @track ownerName    = '';
    @track ownerEmail   = '';
    @track mobile       = '';
    @track ownerType    = '';
    @track address      = '';
    @track pan          = '';
    @track aadhar       = '';

    @wire(getOwnerProfile)
    wiredProfile({ data, error }) {
        if (data) {
            this.ownerName  = data.name      || '';
            this.ownerEmail = data.email     || '';
            this.mobile     = data.mobile    || '';
            this.ownerType  = data.ownerType || 'Individual';
            this.address    = data.address   || '';
            this.pan        = data.pan       || '';
            this.aadhar     = data.aadhar    || '';
            this.isKycDone  = data.isKycDone;
            if (data.isKycDone) {
                setTimeout(() => {
                    this[NavigationMixin.Navigate]({
                        type: 'comm__namedPage',
                        attributes: { name: 'Home' }
                    });
                }, 1500);
            }
        } else if (error) {
            this.errorMsg = error?.body?.message || 'Could not load your profile.';
        }
    }

    get isStep1()    { return this.currentStep === 1; }
    get isStep2()    { return this.currentStep === 2; }
    get step1Class() { return this.currentStep >= 1 ? 'step step-active' : 'step'; }
    get step2Class() { return this.currentStep >= 2 ? 'step step-active' : 'step'; }

    handleInput(event) {
        const field = event.target.dataset.field;
        const value = event.target.value;
        if (field === 'mobile')    this.mobile    = value;
        if (field === 'ownerType') this.ownerType = value;
        if (field === 'address')   this.address   = value;
        if (field === 'pan')       this.pan       = value.toUpperCase();
        if (field === 'aadhar')    this.aadhar    = value.replace(/\D/g, '');
    }

    goToStep2() {
        this.errorMsg = null;
        if (!this.mobile || this.mobile.length !== 10) {
            this.errorMsg = 'Please enter a valid 10-digit mobile number.'; return;
        }
        if (!this.ownerType) {
            this.errorMsg = 'Please select Owner Type.'; return;
        }
        if (!this.address) {
            this.errorMsg = 'Please enter your communication address.'; return;
        }
        this.currentStep = 2;
    }

    goToStep1() { this.currentStep = 1; this.errorMsg = null; }

    async handleSubmit() {
        this.errorMsg = null;
        const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        if (!panRegex.test(this.pan)) {
            this.errorMsg = 'Invalid PAN. Example: ABCDE1234F'; return;
        }
        if (!this.aadhar || this.aadhar.length !== 12) {
            this.errorMsg = 'Aadhar must be exactly 12 digits.'; return;
        }
        this.isSubmitting = true;
        try {
            await saveKyc({
                pan: this.pan, aadhar: this.aadhar,
                ownerType: this.ownerType, address: this.address,
                mobile: this.mobile
            });
            this.dispatchEvent(new ShowToastEvent({
                title: 'eKYC Verified! 🎉',
                message: 'Your profile is now active. Welcome to the portal!',
                variant: 'success'
            }));
            this.isKycDone = true;
            setTimeout(() => {
                this[NavigationMixin.Navigate]({
                    type: 'comm__namedPage',
                    attributes: { name: 'Home' }
                });
            }, 2000);
        } catch (error) {
            this.errorMsg = error?.body?.message || 'Submission failed. Please try again.';
        } finally {
            this.isSubmitting = false;
        }
    }
}
