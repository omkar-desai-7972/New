import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin }              from 'lightning/navigation';

// Reuses your EXISTING Apex — no backend changes
import getDashboardSummary from '@salesforce/apex/PropertyOwnerDashboardController.getDashboardSummary';
import getMyProperties     from '@salesforce/apex/PropertyOwnerDashboardController.getMyProperties';
import getRecentPayments   from '@salesforce/apex/PropertyOwnerDashboardController.getRecentPayments';

const TABS = [
    { label: 'Tax assessments', value: 'assessments' },
    { label: 'Tax payments',    value: 'payments' }
];

export default class TaxAndPaymentsV2 extends NavigationMixin(LightningElement) {

    // ── State ─────────────────────────────────────────────────────────
    @track summary       = {};
    @track assessments   = [];
    @track payments      = [];
    @track activeTab     = 'assessments';
    @track searchTerm    = '';
    @track debouncedSearch = '';
    @track summaryLoaded   = false;
    @track assessmentsLoaded = false;
    @track paymentsLoaded  = false;
    @track errorBanner     = null;

    _searchTimer;

    // ── Wires ─────────────────────────────────────────────────────────
    @wire(getDashboardSummary)
    wiredSummary({ data, error }) {
        if (data) {
            this.summary       = data;
            this.summaryLoaded = true;
        } else if (error) {
            this.errorBanner = this._extractError(error);
        }
    }

    // getMyProperties is cacheable=false, so it can't be used with @wire —
    // we call it imperatively instead. Each property carries its latest
    // assessment, which is the assessment row we show.
    connectedCallback() {
        this.loadAssessments();
    }

    async loadAssessments() {
        this.assessmentsLoaded = false;
        try {
            const data = await getMyProperties({
                statusFilter: 'All',
                searchTerm: this.debouncedSearch
            });
            this.assessments = data
                .filter(p => p.assessmentId)
                .map(p => this._enrichAssessment(p));
        } catch (error) {
            this.errorBanner = this._extractError(error);
        }
        this.assessmentsLoaded = true;
    }

    @wire(getRecentPayments, { limitCount: 100 })
    wiredPayments({ data, error }) {
        if (data) {
            this.payments = data.map(p => this._enrichPayment(p));
            this.paymentsLoaded = true;
        } else if (error) {
            this.paymentsLoaded = true;
        }
    }

    // ── Derived ───────────────────────────────────────────────────────
    get tabs() {
        return TABS.map(t => ({
            ...t,
            cssClass: t.value === this.activeTab ? 'tab tab-active' : 'tab'
        }));
    }
    get showAssessments() { return this.activeTab === 'assessments'; }
    get showPayments()    { return this.activeTab === 'payments'; }

    get hasAssessments()  { return this.assessments?.length > 0; }
    get hasPayments()     { return this.payments?.length > 0; }

    get fmtTaxDue()       { return this._inr(this.summary?.totalTaxDue); }
    get fmtTaxPaid()      { return this._inr(this.summary?.totalTaxPaid); }
    get overdueCount()    { return this.summary?.overduePayments ?? 0; }
    get assessmentCount() { return this.assessments?.length ?? 0; }

    get skeletonItems()   { return [1, 2, 3, 4]; }

    // ── Handlers ──────────────────────────────────────────────────────
    handleTab(e) {
        this.activeTab = e.currentTarget.dataset.value;
    }

    handleSearch(e) {
        this.searchTerm = e.target.value;
        clearTimeout(this._searchTimer);
        this._searchTimer = setTimeout(() => {
            this.debouncedSearch = this.searchTerm;
            this.loadAssessments();
        }, 320);
    }

    handlePay(e) {
        const { propertyId, assessmentId } = e.currentTarget.dataset;
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: { name: 'Make_Payment__c' },
            state: { propertyId, assessmentId }
        });
    }

    dismissError() { this.errorBanner = null; }

    // ── Enrichment ────────────────────────────────────────────────────
    _enrichAssessment(p) {
        const isOverdue = p.isOverdue;
        const isPaid    = p.paymentStatus === 'Success' || p.paymentStatus === 'Paid';
        const isPending = p.paymentStatus === 'Pending Verification';
        let badge = { label: 'Due', cls: 'badge badge-pending' };
        if (isPaid)         badge = { label: 'Paid',            cls: 'badge badge-paid' };
        else if (isPending) badge = { label: 'Verifying',       cls: 'badge badge-pending' };
        else if (isOverdue) badge = { label: 'Overdue',         cls: 'badge badge-overdue' };

        return {
            propertyId:   p.propertyId,
            assessmentId: p.assessmentId,
            propertyName: p.propertyName,
            shortAddress: this._shortAddr(p.propertyAddress),
            taxAmountFmt: this._inr(p.annualTax),
            dueDateFmt:   this._fmtDate(p.taxDueDate),
            fyLabel:      p.assessmentYear
                ? `FY ${p.assessmentYear - 1}-${String(p.assessmentYear).slice(-2)}`
                : '',
            badge,
            showPayButton: !isPaid && !isPending && p.annualTax != null
        };
    }

    _enrichPayment(p) {
        const cls = p.paymentStatus === 'Success' ? 'pay-pill pay-success'
                  : p.paymentStatus === 'Failed'  ? 'pay-pill pay-failed'
                  : 'pay-pill pay-pending';
        return {
            ...p,
            statusClass: cls,
            amountFmt:   this._inr(p.taxAmount),
            dateFmt:     this._fmtDate(p.paymentDate),
            fyLabel:     p.assessmentYear ? `FY ${p.assessmentYear}` : ''
        };
    }

    _inr(n) {
        if (n == null) return '₹0';
        return '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });
    }

    _fmtDate(d) {
        if (!d) return '—';
        return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    _shortAddr(a) {
        if (!a) return '';
        return a.length > 60 ? a.slice(0, 57) + '…' : a;
    }

    _extractError(e) {
        return e?.body?.message || e?.message || 'Something went wrong loading data.';
    }
}