import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import getStats            from '@salesforce/apex/RevenueAdminConsoleController.getStats';
import getZoneBreakdown    from '@salesforce/apex/RevenueAdminConsoleController.getZoneBreakdown';
import getPendingClerk     from '@salesforce/apex/RevenueAdminConsoleController.getPendingClerk';
import getPendingTaxOfficer from '@salesforce/apex/RevenueAdminConsoleController.getPendingTaxOfficer';

/**
 * revenueAdminConsole
 * -------------------
 * Org-wide oversight dashboard for the Revenue Admin (department head). Read-only:
 * shows revenue + pipeline stats, a zone-wise property breakdown, and every
 * property waiting on the Clerk or the Tax Officer. Imperative Apex (cacheable=false)
 * so each load/refresh shows live numbers. Drill into any record to act on it.
 */
export default class RevenueAdminConsole extends NavigationMixin(LightningElement) {

    @track stats           = {};
    @track zones           = [];
    @track pendingClerk    = [];
    @track pendingOfficer  = [];
    @track isLoading       = true;
    @track errorMsg        = null;

    connectedCallback() {
        this.loadAll();
    }

    async loadAll() {
        this.isLoading = true;
        this.errorMsg  = null;
        try {
            const [stats, zones, clerk, officer] = await Promise.all([
                getStats(), getZoneBreakdown(), getPendingClerk(), getPendingTaxOfficer()
            ]);
            this.stats          = this.decorateStats(stats);
            this.zones          = zones.map(z => this.decorateZone(z));
            this.pendingClerk   = clerk.map(p => this.decorateProperty(p));
            this.pendingOfficer = officer.map(p => this.decorateProperty(p));
        } catch (e) {
            this.errorMsg = this.msg(e);
        } finally {
            this.isLoading = false;
        }
    }

    // ── Derived ───────────────────────────────────────────────────────────
    get hasZones()          { return this.zones && this.zones.length > 0; }
    get hasPendingClerk()   { return this.pendingClerk && this.pendingClerk.length > 0; }
    get hasPendingOfficer() { return this.pendingOfficer && this.pendingOfficer.length > 0; }

    // ── Actions ───────────────────────────────────────────────────────────
    handleOpenProperty(event) {
        this.navigateToRecord(event.currentTarget.dataset.id, 'Property__c');
    }

    handleRefresh() { this.loadAll(); }

    // ── Internals ─────────────────────────────────────────────────────────
    navigateToRecord(recordId, objectApiName) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: { recordId, objectApiName, actionName: 'view' }
        });
    }

    decorateStats(s) {
        return {
            ...s,
            billedLabel:      this.fmtMoney(s.totalBilled),
            collectedLabel:   this.fmtMoney(s.totalCollected),
            outstandingLabel: this.fmtMoney(s.totalOutstanding)
        };
    }

    decorateZone(z) {
        return {
            ...z,
            annualTaxLabel: this.fmtMoney(z.annualTax),
            // visual weight: how much of the zone is already Active
            activePct: z.total ? Math.round((z.active / z.total) * 100) : 0
        };
    }

    decorateProperty(p) {
        const waiting = p.daysWaiting == null ? '' : p.daysWaiting + 'd waiting';
        return {
            ...p,
            wardLabel:    p.wardNumber != null ? 'Ward ' + p.wardNumber : '',
            areaLabel:    p.builtUpArea != null ? p.builtUpArea + ' sq.ft' : '',
            dateLabel:    this.fmtDate(p.registrationDate),
            waitingLabel: waiting,
            // flag anything sitting in a queue for more than two weeks
            isStale:      p.daysWaiting != null && p.daysWaiting > 14
        };
    }

    fmtMoney(n) {
        if (n == null) return '₹0';
        return '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });
    }

    fmtDate(d) {
        if (!d) return '';
        return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    toast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }

    msg(e) {
        return (e && e.body && e.body.message) ? e.body.message : 'Something went wrong.';
    }
}
