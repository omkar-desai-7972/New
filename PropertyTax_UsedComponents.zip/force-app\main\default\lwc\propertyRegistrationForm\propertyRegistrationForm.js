import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent }  from 'lightning/platformShowToastEvent';
import communityBasePath   from '@salesforce/community/basePath';
import getFormOptions      from '@salesforce/apex/PropertyRegistrationController.getFormOptions';
import registerProperty    from '@salesforce/apex/PropertyRegistrationController.registerProperty';

/**
 *  propertyRegistrationForm
 *  ------------------------
 *  LWC version of the Property Registration page. Mirrors the existing Flow/form
 *  fields and writes a Property__c via PropertyRegistrationController.
 *
 *  Live validation: each numeric/date field is validated on every keystroke and a
 *  message is shown directly below the field. The allowed range is always visible
 *  as a hint; if the typed value falls outside it, the hint turns into a red error.
 */

// Validation bounds (kept in one place so the hint text and the checks never drift).
const WARD_MIN = 1;
const WARD_MAX = 200;          // Greater Chennai Corporation has 200 wards
const YEAR_MIN = 1900;
const AREA_MIN = 1;            // sq ft (> 0)
const AREA_MAX = 1000000;      // sanity cap

export default class PropertyRegistrationForm extends NavigationMixin(LightningElement) {

    today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

    @track registrationDate = new Date().toISOString().slice(0, 10); // today by default
    @track builtUpArea      = null;
    @track constructionYear = null;
    @track wardNumber       = null;
    @track zone             = '';
    @track doorNumber       = '';
    @track propertyAddress  = '';
    @track propertyType     = '';

    // Per-field live error messages (empty string = valid)
    @track builtUpAreaError      = '';
    @track constructionYearError = '';
    @track wardNumberError       = '';

    @track zoneOptions         = [];
    @track propertyTypeOptions = [];

    @track isSaving  = false;
    @track isSuccess = false;
    @track errorMsg  = null;
    @track newRecordId;

    @wire(getFormOptions)
    wiredOptions({ data, error }) {
        if (data) {
            this.zoneOptions         = data.zones;
            this.propertyTypeOptions = data.propertyTypes;
        } else if (error) {
            this.errorMsg = error?.body?.message || 'Could not load picklist options.';
        }
    }

    // ── Dynamic range hints (shown under each field) ──────────────────────────
    get currentYear()    { return new Date().getFullYear(); }
    get areaHint()       { return `Allowed: greater than 0 and up to ${AREA_MAX.toLocaleString('en-IN')} sq ft.`; }
    get yearHint()       { return `Allowed range: ${YEAR_MIN} to ${this.currentYear}.`; }
    get wardHint()       { return `Allowed range: ${WARD_MIN} to ${WARD_MAX}.`; }
    get regDateHint()    { return "Automatically set to today's date."; }

    // ── Validators (return '' when valid, else the message) ───────────────────
    validateArea(v) {
        if (v === '' || v === null) return 'Built-up area is required.';
        const n = Number(v);
        if (isNaN(n))      return 'Enter a valid number.';
        if (n < AREA_MIN)  return 'Built-up area must be greater than 0.';
        if (n > AREA_MAX)  return `Built-up area cannot exceed ${AREA_MAX.toLocaleString('en-IN')} sq ft.`;
        return '';
    }
    validateYear(v) {
        if (v === '' || v === null) return 'Construction year is required.';
        const n = Number(v);
        if (isNaN(n) || !Number.isInteger(n)) return 'Enter a valid 4-digit year.';
        if (n < YEAR_MIN || n > this.currentYear) return `Construction year must be between ${YEAR_MIN} and ${this.currentYear}.`;
        return '';
    }
    validateWard(v) {
        if (v === '' || v === null) return 'Ward number is required.';
        const n = Number(v);
        if (isNaN(n) || !Number.isInteger(n)) return 'Enter a valid whole number.';
        if (n < WARD_MIN || n > WARD_MAX) return `Ward number must be between ${WARD_MIN} and ${WARD_MAX}.`;
        return '';
    }

    // ── Field handlers (validate live on every keystroke) ─────────────────────
    // Registration date is locked to today, so it has no handler.
    handleBuiltUpArea(e)  { this.builtUpArea      = e.target.value; this.builtUpAreaError      = this.validateArea(this.builtUpArea); }
    handleConstructionYear(e) {
        // Keep digits only so the year shows as "2024", not a grouped "2,024".
        this.constructionYear = e.target.value.replace(/\D/g, '');
        this.constructionYearError = this.validateYear(this.constructionYear);
    }
    handleWardNumber(e)   { this.wardNumber       = e.target.value; this.wardNumberError       = this.validateWard(this.wardNumber); }
    handleZone(e)         { this.zone             = e.detail.value; }
    handleDoorNumber(e)   { this.doorNumber       = e.target.value; }
    handlePropertyAddress(e) { this.propertyAddress = e.target.value; }
    handlePropertyType(e) { this.propertyType     = e.detail.value; }

    // ── Submit ────────────────────────────────────────────────────────────────
    handleSubmit() {
        this.errorMsg = null;

        // Re-run the range validators so untouched fields are caught too.
        this.builtUpAreaError      = this.validateArea(this.builtUpArea);
        this.constructionYearError = this.validateYear(this.constructionYear);
        this.wardNumberError       = this.validateWard(this.wardNumber);

        const hasRangeError = this.builtUpAreaError ||
                              this.constructionYearError || this.wardNumberError;

        // Native validation on inputs/comboboxes/textareas (required, etc.).
        const fields = [...this.template.querySelectorAll('lightning-input, lightning-combobox, lightning-textarea')];
        const allValid = fields.reduce((valid, f) => f.reportValidity() && valid, true);

        if (!allValid || hasRangeError) {
            this.errorMsg = 'Please fix the highlighted fields before submitting.';
            return;
        }

        this.isSaving = true;
        registerProperty({
            registrationDate: this.registrationDate,
            builtUpArea     : this.builtUpArea,
            constructionYear: this.constructionYear,
            wardNumber      : this.wardNumber,
            zone            : this.zone,
            doorNumber      : this.doorNumber,
            propertyAddress : this.propertyAddress,
            propertyType    : this.propertyType
        })
            .then(recordId => {
                this.newRecordId = recordId;
                this.isSuccess   = true;
                this.isSaving    = false;
                this.dispatchEvent(new ShowToastEvent({
                    title  : 'Property Registered',
                    message: 'Your property has been submitted for clerk review.',
                    variant: 'success'
                }));
            })
            .catch(err => {
                this.isSaving = false;
                this.errorMsg = err?.body?.message || 'Could not register the property.';
            });
    }

    handleRegisterAnother() {
        this.isSuccess        = false;
        this.errorMsg         = null;
        this.newRecordId      = null;
        this.registrationDate = new Date().toISOString().slice(0, 10);
        this.builtUpArea      = null;
        this.constructionYear = null;
        this.wardNumber       = null;
        this.zone             = '';
        this.doorNumber       = '';
        this.propertyAddress  = '';
        this.propertyType     = '';
        this.builtUpAreaError      = '';
        this.constructionYearError = '';
        this.wardNumberError       = '';
    }

    handleGoToProperties() {
        const base = communityBasePath || '';
        this[NavigationMixin.Navigate]({
            type      : 'standard__webPage',
            attributes: { url: `${base}/my-properties` }
        });
    }
}
