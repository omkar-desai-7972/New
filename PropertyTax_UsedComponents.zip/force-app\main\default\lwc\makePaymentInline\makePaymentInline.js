import { LightningElement, api, track, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getPaymentDetails    from '@salesforce/apex/MakePaymentController.getPaymentDetails';
import generatePaymentLink  from '@salesforce/apex/RazorpayService.generatePaymentLink';
import verifyAndConfirm     from '@salesforce/apex/RazorpayService.verifyAndConfirm';

/**
 *  makePaymentInline
 *  -----------------
 *  Razorpay payment without a VF page and without client-side checkout.js.
 *
 *  Pay  → Apex (RazorpayService) creates a Razorpay Payment Link via a Named
 *         Credential and returns its hosted short_url; we redirect the browser
 *         there. Payment happens on Razorpay's own page (so no CSP issues).
 *  Done → Razorpay's webhook (RazorpayWebhookHandler) marks the assessment Paid,
 *         and routes the user back here with razorpay_payment_link_status=paid.
 */
export default class MakePaymentInline extends NavigationMixin(LightningElement) {

    @api assessmentId;
    @track details       = {};
    @track isLoading     = true;
    @track isProcessing  = false;
    @track isSuccess     = false;
    @track errorMsg      = null;
    @track transactionId = '';

    connectedCallback() {
        const params = new URLSearchParams(window.location.search);

        // Resolve assessmentId: @api (Builder) → URL param → Razorpay reference_id.
        if (!this.assessmentId) {
            let aId = params.get('assessmentId');
            if (!aId) {
                const ref = params.get('razorpay_payment_link_reference_id');
                if (ref && ref.indexOf('REF_') === 0) {
                    const parts = ref.split('_');
                    if (parts.length > 1) aId = parts[1];
                }
            }
            if (aId) this.assessmentId = aId;
        }

        // Returning from Razorpay — verify server-side before showing success.
        const linkStatus = params.get('razorpay_payment_link_status');
        const plinkId    = params.get('razorpay_payment_link_id');
        if (linkStatus && plinkId) {
            this.finishPayment(plinkId, params.get('razorpay_payment_id') || '');
            return;
        }

        if (this.assessmentId) {
            this.loadDetails();
        } else {
            this.isLoading = false;
        }
    }

    finishPayment(paymentLinkId, razorpayPaymentId) {
        this.isLoading    = false;
        this.isProcessing = true;
        verifyAndConfirm({
            assessmentId     : this.assessmentId,
            paymentLinkId    : paymentLinkId,
            razorpayPaymentId: razorpayPaymentId
        })
            .then(status => {
                this.isProcessing = false;
                if (status === 'Success') {
                    this.transactionId = razorpayPaymentId || paymentLinkId;
                    this.isSuccess     = true;
                    if (this.assessmentId) this.loadDetails(); // fill amount for the success screen
                } else {
                    this.errorMsg = 'Payment not completed (status: ' + status + ').';
                    if (this.assessmentId) this.loadDetails();
                }
            })
            .catch(err => {
                this.isProcessing = false;
                this.errorMsg = err?.body?.message || 'Could not verify the payment.';
                if (this.assessmentId) this.loadDetails();
            });
    }

    @wire(CurrentPageReference)
    pageRef(ref) {
        if (ref?.state?.assessmentId && !this.assessmentId) {
            this.assessmentId = ref.state.assessmentId;
            this.loadDetails();
        }
    }

    loadDetails() {
        if (!this.assessmentId) return;
        getPaymentDetails({ assessmentId: this.assessmentId })
            .then(data => {
                this.details   = data;
                this.isLoading = false;
            })
            .catch(error => {
                this.errorMsg  = error?.body?.message || 'Could not load payment details.';
                this.isLoading = false;
            });
    }

    // ── Pay → Razorpay Payment Link (server-side, Named Credential) ────────
    async handlePayNow() {
        this.errorMsg     = null;
        this.isProcessing = true;
        try {
            // Return to this same page (carry assessmentId) after payment.
            const portalUrl = window.location.origin + window.location.pathname +
                              '?assessmentId=' + encodeURIComponent(this.assessmentId);

            const shortUrl = await generatePaymentLink({
                amount      : this.details.taxAmount,
                assessmentId: this.assessmentId,
                portalUrl   : portalUrl
            });

            if (shortUrl) {
                window.location.href = shortUrl;   // hand off to Razorpay
            } else {
                throw new Error('No payment link returned.');
            }
        } catch (err) {
            this.isProcessing = false;
            this.errorMsg     = err?.body?.message || err?.message || 'Could not start payment.';
        }
    }

    // ── View helpers ──────────────────────────────────────────────────────

    get showPayment()  { return !this.isLoading && !this.isSuccess && !this.isProcessing && !this.details.alreadyPaid; }
    get alreadyPaid()  { return !this.isLoading && !this.isSuccess && !this.isProcessing && this.details.alreadyPaid; }
    get hasDiscount()  { return this.details.discountAmount > 0; }
    get hasPenalty()   { return this.details.penaltyAmount  > 0; }

    get formattedBase()     { return this.fmt(this.details.baseAmount); }
    get formattedDiscount() { return this.fmt(this.details.discountAmount); }
    get formattedPenalty()  { return this.fmt(this.details.penaltyAmount); }
    get formattedTotal()    { return this.fmt(this.details.taxAmount); }

    get formattedDueDate() {
        if (!this.details.dueDate) return '—';
        return new Date(this.details.dueDate).toLocaleDateString('en-IN', {
            day: '2-digit', month: 'short', year: 'numeric'
        });
    }

    get dueDateClass()   { return this.details.isOverdue ? 'due-date-box due-overdue' : 'due-date-box due-normal'; }
    get dueDateIcon()    { return this.details.isOverdue ? '⚠️' : '📅'; }
    get dueDateMessage() { return this.details.isOverdue ? 'Overdue — penalty applied' : 'Pay before due date for discount'; }

    handleBack() {
        this[NavigationMixin.Navigate]({
            type      : 'comm__namedPage',
            attributes: { name: 'Home' }
        });
    }

    // Go to the detail page of the property that was just paid for.
    handleViewProperty() {
        if (this.details && this.details.propertyId) {
            this[NavigationMixin.Navigate]({
                type      : 'comm__namedPage',
                attributes: { name: 'property_Detail__c' },
                state     : { propertyId: this.details.propertyId }
            });
        } else {
            this.handleBack();
        }
    }

    fmt(val) {
        if (val == null) return '0';
        return Number(val).toLocaleString('en-IN', { maximumFractionDigits: 2 });
    }
}