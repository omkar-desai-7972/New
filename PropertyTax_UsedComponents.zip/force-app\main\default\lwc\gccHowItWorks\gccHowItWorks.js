import { LightningElement, api } from 'lwc';

/**
 * GCC How It Works
 * ----------------
 * A simple, presentational component that explains how a citizen pays
 * their property tax in four steps.
 *
 * It has NO Apex and NO wire adapters - everything shown on screen comes
 * from the @api properties below, which an admin can edit in the
 * Experience Builder. This makes it a good first component to learn from.
 */
export default class GccHowItWorks extends LightningElement {
    // Section heading text (editable in the builder)
    @api kicker = 'Getting started';
    @api heading = 'How to pay your property tax';
    @api intro =
        'Four simple steps - from registering your property to tracking your payment status.';

    /**
     * The four steps shown as cards.
     *
     * This is a "getter": LWC runs it whenever the template needs `steps`.
     * Each step is a plain object. The `key` is required by the template's
     * for:each loop so LWC can track each item efficiently.
     */
    get steps() {
        return [
            {
                key: 'register',
                number: '1',
                accent: 'saffron',
                title: 'Register your property',
                description:
                    'Add your property details and ward so the corporation can identify your holding.'
            },
            {
                key: 'assess',
                number: '2',
                accent: 'blue',
                title: 'Get your assessment',
                description:
                    'We calculate the tax due based on the property type, area and usage.'
            },
            {
                key: 'pay',
                number: '3',
                accent: 'green',
                title: 'Pay online',
                description:
                    'Settle your dues securely, any time, using net banking, UPI or card.'
            },
            {
                key: 'track',
                number: '4',
                accent: 'saffron',
                title: 'Track your status',
                description:
                    'View your property details, payment status and assessment history anytime under My Properties.'
            }
        ];
    }
}