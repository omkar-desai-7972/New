import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin }              from 'lightning/navigation';
import { ShowToastEvent }               from 'lightning/platformShowToastEvent';
import getDashboardSummary from '@salesforce/apex/PropertyOwnerDashboardController.getDashboardSummary';
import getMyProperties     from '@salesforce/apex/PropertyOwnerDashboardController.getMyProperties';
import getRecentPayments   from '@salesforce/apex/PropertyOwnerDashboardController.getRecentPayments';

const FILTER_OPTIONS = [
    { label: 'All',           value: 'All' },
    { label: 'Active',        value: 'Active' },
    { label: 'Pending',       value: 'Pending Clerk Review' },
    { label: 'Rejected',      value: 'Rejected' },
    { label: 'Pending Taxes', value: 'Pending Taxes' },
];

// A property's tax is considered "not paid" when it has an assessment
// and its payment status is none of these.
const SETTLED_PAYMENT_STATES = ['Paid', 'Success', 'Pending Verification'];

const PAYMENT_STATUS_CSS = {
    'Success'             : 'badge badge-success',
    'Failed'              : 'badge badge-error',
    'Pending Verification': 'badge badge-warning',
};

export default class PropertyOwnerDashboard extends NavigationMixin(LightningElement) {

    @track summary          = {};
    @track properties       = [];
    @track recentPayments   = [];
    @track errorMessage     = null;
    @track searchTerm       = '';
    @track activeFilter     = 'All';
    @track debouncedSearch  = '';

    @track summaryLoading    = true;
    @track summaryLoaded     = false;
    @track propertiesLoading = true;
    @track propertiesLoaded  = false;
    @track paymentsLoading   = true;
    @track paymentsLoaded    = false;

    _searchTimer = null;

    get skeletonArray() { return [1,2,3,4,5,6]; }

    connectedCallback() {
        this.loadProperties();
    }

 @wire(getDashboardSummary, {})
wiredSummary({ error, data }) {
    if(data) {
        console.log('Summary data:', JSON.stringify(data));
        console.log('Total Paid:', data.totalTaxPaid);
        this.summary        = data;
        this.summaryLoading = false;
        this.summaryLoaded  = true;
    } else if(error) {
        this.summaryLoading = false;
        this.showError(this.extractError(error));
    }
}

    // Properties — imperative call to bypass cache
    loadProperties() {
        this.propertiesLoading = true;
        this.propertiesLoaded  = false;

        // "Pending Taxes" isn't a property status, so ask the server for all
        // properties and keep the unpaid ones on the client.
        const isPendingTaxes = this.activeFilter === 'Pending Taxes';

        getMyProperties({
            statusFilter: isPendingTaxes ? 'All' : this.activeFilter,
            searchTerm  : this.debouncedSearch
        })
        .then(data => {
            let list = data.map(p => ({ ...p, isSelected: false }));
            if (isPendingTaxes) {
                list = list.filter(p =>
                    p.assessmentId != null &&
                    !SETTLED_PAYMENT_STATES.includes(p.paymentStatus)
                );
            }
            this.properties        = list;
            this.propertiesLoading = false;
            this.propertiesLoaded  = true;
        })
        .catch(error => {
            this.propertiesLoading = false;
            this.showError(this.extractError(error));
        });
    }

    // Payments
    @wire(getRecentPayments, { limitCount: 5 })
    wiredPayments({ error, data }) {
        if(data) {
            this.recentPayments = data.map(p => ({
                ...p,
                statusClass: PAYMENT_STATUS_CSS[p.paymentStatus] || 'badge badge-neutral'
            }));
            this.paymentsLoading = false;
            this.paymentsLoaded  = true;
        } else if(error) {
            this.paymentsLoading = false;
        }
    }

    handleSearch(event) {
        this.searchTerm = event.target.value;
        clearTimeout(this._searchTimer);
        this._searchTimer = setTimeout(() => {
            this.debouncedSearch = this.searchTerm;
            this.loadProperties();
        }, 350);
    }

    get filterOptions() {
        return FILTER_OPTIONS.map(opt => ({
            ...opt,
            cssClass: opt.value === this.activeFilter
                ? 'filter-tab filter-tab-active' : 'filter-tab'
        }));
    }

    handleFilterChange(event) {
        this.activeFilter = event.target.dataset.value;
        this.loadProperties();
    }

    get hasProperties() { return this.properties && this.properties.length > 0; }
    get hasPayments()   { return this.recentPayments && this.recentPayments.length > 0; }

    get formattedTaxDue()  { return this.formatCurrency(this.summary?.totalTaxDue); }
    get formattedTaxPaid() { return this.formatCurrency(this.summary?.totalTaxPaid); }

    handlePropertySelect(event) {
        const selectedId = event.detail.propertyId;
        this.properties  = this.properties.map(p => ({
            ...p, isSelected: p.propertyId === selectedId
        }));
    }

    handleMakePayment(event) {
        const { assessmentId } = event.detail;
        this[NavigationMixin.Navigate]({
            type      : 'comm__namedPage',
            attributes: { name: 'Make_Payment__c' },
            state     : { assessmentId: assessmentId }
        });
    }

    handleRegisterProperty() {
        this[NavigationMixin.Navigate]({
            type      : 'comm__namedPage',
            attributes: { name: 'Property_Registration__c' }
        });
    }

    handleViewAllPayments() {
        this[NavigationMixin.Navigate]({
            type      : 'comm__namedPage',
            attributes: { name: 'Payment_History__c' }
        });
    }

    formatCurrency(value) {
        if(value == null) return '₹0';
        return '₹' + Number(value).toLocaleString('en-IN', { maximumFractionDigits: 0 });
    }

    extractError(error) {
        if(error?.body?.message) return error.body.message;
        if(error?.message)       return error.message;
        return 'An unexpected error occurred.';
    }

    showError(msg) {
        this.errorMessage = msg;
        this.dispatchEvent(new ShowToastEvent({ title: 'Error', message: msg, variant: 'error' }));
    }

    handleViewDetail(event) {
        const { propertyId } = event.detail;
        this[NavigationMixin.Navigate]({
            type      : 'comm__namedPage',
            attributes: { name: 'property_Detail__c' },
            state     : { propertyId: propertyId }
        });
    }
}