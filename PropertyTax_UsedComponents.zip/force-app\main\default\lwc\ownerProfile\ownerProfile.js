import { LightningElement, track, api } from 'lwc';
import getMyProfile  from '@salesforce/apex/ProfileController.getMyProfile';
import updateProfile from '@salesforce/apex/ProfileController.updateProfile';

export default class OwnerProfile extends LightningElement {

    @track profile;
    @track form = {};
    @track isLoading = true;
    @track isSaving  = false;
    @track loadError = '';
    @track saveError = '';
    @track editMode  = false;   // only for the "complete" card's edit toggle

    /**
     * Expose profile-complete flag so parent components (dashboard)
     * can read it:  this.template.querySelector('c-owner-profile').profileComplete
     */
    @api
    get profileComplete() {
        return this.profile ? this.profile.kycComplete === true : false;
    }

    // ---------- lifecycle ----------

    connectedCallback() {
        this.load();
    }

    async load() {
        this.isLoading = true;
        this.loadError = '';
        try {
            this.profile = await getMyProfile();
            this.fireStatus();
        } catch (e) {
            this.loadError = this.msg(e, 'Contact not linked to your account.');
        } finally {
            this.isLoading = false;
        }
    }

    // ---------- conditional rendering ----------

    get hasProfile()  { return !this.isLoading && !this.loadError && this.profile; }
    get showGate()    { return this.hasProfile && !this.profile.kycComplete; }
    get showSummary() { return this.hasProfile && this.profile.kycComplete; }
    get isViewMode()  { return !this.editMode; }
    get isEditMode()  { return this.editMode; }

    // ---------- display helpers ----------

    get phoneDisplay() {
        return this.profile.phone || 'Not provided';
    }
    get addressDisplay() {
        const p = this.profile;
        const parts = [p.street, p.city, p.state, p.postalCode].filter(Boolean);
        return parts.length ? parts.join(', ') : 'Not provided';
    }
    get maskedPan() {
        const v = this.profile.pan;
        if (!v) return '—';
        return v.length > 4 ? v.slice(0, -4).replace(/./g, 'X') + v.slice(-4) : v;
    }
    get maskedAadhar() {
        const v = this.profile.aadhar;
        if (!v) return '—';
        return v.length === 12 ? 'XXXX XXXX ' + v.slice(-4) : v;
    }

    // ---------- form ----------

    populateForm() {
        this.form = {
            phone:      this.profile.phone      || '',
            street:     this.profile.street      || '',
            city:       this.profile.city        || '',
            state:      this.profile.state       || '',
            postalCode: this.profile.postalCode  || '',
            pan:        this.profile.pan         || '',
            aadhar:     this.profile.aadhar      || ''
        };
    }

    handleChange(event) {
        this.form = { ...this.form, [event.target.dataset.field]: event.target.value };
        this.saveError = '';
    }

    enableEdit() {
        this.populateForm();
        this.editMode = true;
        this.saveError = '';
    }

    cancelEdit() {
        this.editMode = false;
        this.saveError = '';
    }

    async handleSave() {
        // If this is the gate (incomplete), populate form from gate fields
        if (this.showGate && Object.keys(this.form).length === 0) {
            this.populateForm();
        }

        const inputs = [...this.template.querySelectorAll('lightning-input')];
        const valid = inputs.reduce((ok, inp) => {
            inp.reportValidity();
            return ok && inp.checkValidity();
        }, true);
        if (!valid) {
            this.saveError = 'Please correct the highlighted fields.';
            return;
        }

        this.isSaving = true;
        this.saveError = '';
        try {
            this.profile = await updateProfile({
                phone:      this.form.phone,
                street:     this.form.street,
                city:       this.form.city,
                state:      this.form.state,
                postalCode: this.form.postalCode,
                pan:        this.form.pan,
                aadhar:     this.form.aadhar
            });
            this.editMode = false;
            this.fireStatus();
        } catch (e) {
            this.saveError = this.msg(e, 'Could not save. Please try again.');
        } finally {
            this.isSaving = false;
        }
    }

    // ---------- events ----------

    fireStatus() {
        this.dispatchEvent(new CustomEvent('profilestatuschange', {
            detail: { complete: this.profile.kycComplete === true },
            bubbles: true, composed: true
        }));
    }

    // ---------- connectedCallback also populates form for gate ----------

    renderedCallback() {
        if (this.showGate && Object.keys(this.form).length === 0 && this.profile) {
            this.populateForm();
        }
    }

    // ---------- util ----------

    msg(e, fallback) {
        return (e && e.body && e.body.message) ? e.body.message : fallback;
    }
}