// import { LightningElement, api, track } from 'lwc';
// import getPaymentStatus from '@salesforce/apex/MakePaymentController.getPaymentStatus';

// const TYPE_ICONS = {
//     'Individual House'    : '🏠',
//     'Apartment'           : '🏢',
//     'Commercial Complex'  : '🏬',
//     'Government Building' : '🏛️',
// };

// const STATUS_RIBBON = {
//     'Active'               : 'ribbon ribbon-active',
//     'Pending Clerk Review' : 'ribbon ribbon-pending',
//     'Pending Tax Officer'  : 'ribbon ribbon-pending',
//     'Rejected'             : 'ribbon ribbon-rejected',
//     'Inactive'             : 'ribbon ribbon-inactive',
//     'Disputed'             : 'ribbon ribbon-disputed',
// };

// export default class PropertyCard extends LightningElement {

//     @api property    = {};
//     @api isSelected  = false;
//     @track actualPaymentStatus = null;

//     connectedCallback() {
//         if(this.property?.assessmentId) {
//             getPaymentStatus({ assessmentId: this.property.assessmentId })
//                 .then(status => { this.actualPaymentStatus = status; })
//                 .catch(() => { this.actualPaymentStatus = this.property.paymentStatus; });
//         }
//     }

//     get displayStatus() {
//         return this.actualPaymentStatus || this.property?.paymentStatus;
//     }

//     get cardClass() {
//         return this.isSelected ? 'property-card property-card-selected' : 'property-card';
//     }

//     get typeIcon() {
//         return TYPE_ICONS[this.property?.propertyType] || '🏠';
//     }

//     get statusRibbonClass() {
//         return STATUS_RIBBON[this.property?.propertyStatus] || 'ribbon ribbon-inactive';
//     }

//     get hasAssessment() {
//         return !!this.property?.assessmentId;
//     }

//     get canPay() {
//         const blocked = ['Pending Verification', 'Success', 'Paid', 'Failed'];
//         return this.property?.propertyStatus === 'Active'
//             && this.property?.assessmentId != null
//             && !blocked.includes(this.displayStatus);
//     }

//     get formattedTax() {
//         const val = this.property?.annualTax;
//         if(val == null) return '—';
//         return Number(val).toLocaleString('en-IN', { maximumFractionDigits: 0 });
//     }

//     get formattedDueDate() {
//         const d = this.property?.taxDueDate;
//         if(!d) return '—';
//         return new Date(d).toLocaleDateString('en-IN', {
//             day: '2-digit', month: 'short', year: 'numeric'
//         });
//     }

//     get paymentStatusClass() {
//         const statusMap = {
//             'Paid'                : 'pay-badge pay-paid',
//             'Success'             : 'pay-badge pay-paid',
//             'Pending Verification': 'pay-badge pay-verification',
//             'Failed'              : 'pay-badge pay-failed',
//             'Pending'             : 'pay-badge pay-pending'
//         };
//         return statusMap[this.displayStatus] || 'pay-badge pay-pending';
//     }
//     get formattedPaymentStatus() {
//     if(this.displayStatus === 'Success') return 'Paid';
//     return this.displayStatus;
// }

//     handleCardClick() {
//         this.dispatchEvent(new CustomEvent('propertyselect', {
//             detail : { propertyId: this.property.propertyId },
//             bubbles: true, composed: true
//         }));
//     }

//     handleViewDetails(event) {
//         event.stopPropagation();
//         this.dispatchEvent(new CustomEvent('propertyselect', {
//             detail : { propertyId: this.property.propertyId, navigate: true },
//             bubbles: true, composed: true
//         }));
//     }

//     handleMakePayment(event) {
//         event.stopPropagation();
//         this.dispatchEvent(new CustomEvent('makepayment', {
//             detail : {
//                 propertyId  : this.property.propertyId,
//                 assessmentId: this.property.assessmentId
//             },
//             bubbles: true, composed: true
//         }));
//     }
// }


// /*import { LightningElement, api, track, wire } from 'lwc';
// import getPaymentStatus from '@salesforce/apex/MakePaymentController.getPaymentStatus';

// const TYPE_ICONS = {
//     'Individual House'    : '🏠',
//     'Apartment'           : '🏢',
//     'Commercial Complex'  : '🏬',
//     'Government Building' : '🏛️',
// };

// const STATUS_RIBBON = {
//     'Active'               : 'ribbon ribbon-active',
//     'Pending Clerk Review' : 'ribbon ribbon-pending',
//     'Pending Tax Officer'  : 'ribbon ribbon-pending',
//     'Rejected'             : 'ribbon ribbon-rejected',
//     'Inactive'             : 'ribbon ribbon-inactive',
//     'Disputed'             : 'ribbon ribbon-disputed',
// };

// export default class PropertyCard extends LightningElement {

//     @api property    = {};
//     @api isSelected  = false;
//     @track actualPaymentStatus = null;

//     connectedCallback() {
//         if(this.property?.assessmentId) {
//             getPaymentStatus({ assessmentId: this.property.assessmentId })
//                 .then(status => { this.actualPaymentStatus = status; })
//                 .catch(() => { this.actualPaymentStatus = this.property.paymentStatus; });
//         }
//     }

//     get displayStatus() {
//         return this.actualPaymentStatus || this.property?.paymentStatus;
//     }

//     get cardClass() {
//         return this.isSelected ? 'property-card property-card-selected' : 'property-card';
//     }

//     get typeIcon() {
//         return TYPE_ICONS[this.property?.propertyType] || '🏠';
//     }

//     get statusRibbonClass() {
//         return STATUS_RIBBON[this.property?.propertyStatus] || 'ribbon ribbon-inactive';
//     }

//     get hasAssessment() {
//         return !!this.property?.assessmentId;
//     }

//     get canPay() {
//         const blocked = ['Pending Verification', 'Success', 'Paid', 'Failed'];
//         return this.property?.propertyStatus === 'Active'
//             && this.property?.assessmentId != null
//             && !blocked.includes(this.displayStatus);
//     }

//     get formattedTax() {
//         const val = this.property?.annualTax;
//         if(val == null) return '—';
//         return Number(val).toLocaleString('en-IN', { maximumFractionDigits: 0 });
//     }

//     get formattedDueDate() {
//         const d = this.property?.taxDueDate;
//         if(!d) return '—';
//         return new Date(d).toLocaleDateString('en-IN', {
//             day: '2-digit', month: 'short', year: 'numeric'
//         });
//     }

//     get paymentStatusClass() {
//         const statusMap = {
//             'Paid'                : 'pay-badge pay-paid',
//             'Success'             : 'pay-badge pay-paid',
//             'Pending Verification': 'pay-badge pay-verification',
//             'Failed'              : 'pay-badge pay-failed',
//             'Pending'             : 'pay-badge pay-pending'
//         };
//         return statusMap[this.displayStatus] || 'pay-badge pay-pending';
//     }

//     handleCardClick() {
//         this.dispatchEvent(new CustomEvent('propertyselect', {
//             detail : { propertyId: this.property.propertyId },
//             bubbles: true, composed: true
//         }));
//     }

//     handleViewDetails(event) {
//         event.stopPropagation();
//         this.dispatchEvent(new CustomEvent('propertyselect', {
//             detail : { propertyId: this.property.propertyId, navigate: true },
//             bubbles: true, composed: true
//         }));
//     }

//     handleMakePayment(event) {
//         event.stopPropagation();
//         this.dispatchEvent(new CustomEvent('makepayment', {
//             detail : {
//                 propertyId  : this.property.propertyId,
//                 assessmentId: this.property.assessmentId
//             },
//             bubbles: true, composed: true
//         }));
//     }
// }*/



import { LightningElement, api, track } from 'lwc';
import getPaymentStatus from '@salesforce/apex/MakePaymentController.getPaymentStatus';

const TYPE_ICONS = {
    'Individual House'    : '🏠',
    'Apartment'           : '🏢',
    'Commercial Complex'  : '🏬',
    'Government Building' : '🏛️',
};

const STATUS_RIBBON = {
    'Active'               : 'ribbon ribbon-active',
    'Pending Clerk Review' : 'ribbon ribbon-pending',
    'Pending Tax Officer'  : 'ribbon ribbon-pending',
    'Rejected'             : 'ribbon ribbon-rejected',
    'Inactive'             : 'ribbon ribbon-inactive',
    'Disputed'             : 'ribbon ribbon-disputed',
};

export default class PropertyCard extends LightningElement {

    @api property    = {};
    @api isSelected  = false;
    @track actualPaymentStatus = null;

    connectedCallback() {
        if(this.property?.assessmentId) {
            getPaymentStatus({ assessmentId: this.property.assessmentId })
                .then(status => { this.actualPaymentStatus = status; })
                .catch(() => { this.actualPaymentStatus = this.property.paymentStatus; });
        }
    }

    get displayStatus() {
        return this.actualPaymentStatus || this.property?.paymentStatus;
    }

    get cardClass() {
        return this.isSelected ? 'property-card property-card-selected' : 'property-card';
    }

    get typeIcon() {
        return TYPE_ICONS[this.property?.propertyType] || '🏠';
    }

    get statusRibbonClass() {
        return STATUS_RIBBON[this.property?.propertyStatus] || 'ribbon ribbon-inactive';
    }

    get hasAssessment() {
        return !!this.property?.assessmentId;
    }

    get canPay() {
        const blocked = ['Pending Verification', 'Success', 'Paid', 'Failed'];
        return this.property?.propertyStatus === 'Active'
            && this.property?.assessmentId != null
            && !blocked.includes(this.displayStatus);
    }

    get formattedTax() {
        const val = this.property?.annualTax;
        if(val == null) return '—';
        return Number(val).toLocaleString('en-IN', { maximumFractionDigits: 0 });
    }

    get formattedDueDate() {
        const d = this.property?.taxDueDate;
        if(!d) return '—';
        return new Date(d).toLocaleDateString('en-IN', {
            day: '2-digit', month: 'short', year: 'numeric'
        });
    }

    get paymentStatusClass() {
        const statusMap = {
            'Paid'                : 'pay-badge pay-paid',
            'Success'             : 'pay-badge pay-paid',
            'Pending Verification': 'pay-badge pay-verification',
            'Failed'              : 'pay-badge pay-failed',
            'Pending'             : 'pay-badge pay-pending'
        };
        return statusMap[this.displayStatus] || 'pay-badge pay-pending';
    }

    get formattedPaymentStatus() {
        if(this.displayStatus === 'Success') return 'Paid';
        return this.displayStatus;
    }

    // Navigate to detail page via parent
    handleCardClick() {
        this.dispatchEvent(new CustomEvent('viewdetail', {
            detail : { propertyId: this.property.propertyId },
            bubbles: true, composed: true
        }));
    }

    handleViewDetails(event) {
        event.stopPropagation();
        this.dispatchEvent(new CustomEvent('viewdetail', {
            detail : { propertyId: this.property.propertyId },
            bubbles: true, composed: true
        }));
    }

    handleMakePayment(event) {
        event.stopPropagation();
        this.dispatchEvent(new CustomEvent('makepayment', {
            detail : {
                propertyId  : this.property.propertyId,
                assessmentId: this.property.assessmentId
            },
            bubbles: true, composed: true
        }));
    }
}