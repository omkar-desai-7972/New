import { LightningElement, track } from 'lwc';
import isKycComplete from '@salesforce/apex/PropertyOwnerDashboardController.isKycComplete';

/**
 * kycGate
 * -------
 * Drop this on any page that must be locked for unverified citizens.
 *
 * On load it asks the server whether the logged-in owner has completed
 * PAN + Aadhaar verification (Property_Owner__c.Active__c). If NOT, it
 * renders a non-dismissible full-screen overlay containing the existing
 * <c-owner-profile> gate (which captures PAN + Aadhaar and shows the
 * "locked features" list). The moment ownerProfile reports completion via
 * its `profilestatuschange` event, the overlay disappears and the page
 * behind it becomes usable — no reload needed.
 *
 * NOTE: isKycComplete is @AuraEnabled(cacheable=false), so it must be
 * called IMPERATIVELY — @wire only works with cacheable=true methods.
 *
 * Reuses existing Apex only (PropertyOwnerDashboardController.isKycComplete
 * + ProfileController behind ownerProfile). No backend changes.
 */
export default class KycGate extends LightningElement {

    // Assume verified until the server proves otherwise — avoids a modal
    // "flash" on every page load for already-verified users.
    @track _kycComplete = true;
    @track _loaded      = false;

    _bodyLocked = false;

    connectedCallback() {
        this.checkKyc();
    }

    async checkKyc() {
        try {
            const result = await isKycComplete();
            this._kycComplete = result === true;
        } catch (e) {
            // If we genuinely can't tell (e.g. admin preview, no contact),
            // fail open so we never trap a user behind a broken gate.
            this._kycComplete = true;
        } finally {
            this._loaded = true;
        }
    }

    // Show the overlay only once we KNOW the user is unverified.
    get showGate() {
        return this._loaded && !this._kycComplete;
    }

    // Fired by <c-owner-profile> on load and after a successful save.
    handleStatus(event) {
        const complete = event && event.detail && event.detail.complete === true;
        if (complete) {
            this._kycComplete = true;
            // Let host pages / dashboards know features can unlock now.
            this.dispatchEvent(new CustomEvent('kyccomplete', {
                bubbles: true, composed: true
            }));
        }
    }

    // Lock background scroll while the gate is open.
    renderedCallback() {
        const open = this.showGate;
        if (open !== this._bodyLocked) {
            this._bodyLocked = open;
            try {
                document.body.style.overflow = open ? 'hidden' : '';
            } catch (e) {
                // Some Locker contexts restrict body access — non-fatal.
            }
        }
    }

    disconnectedCallback() {
        if (this._bodyLocked) {
            this._bodyLocked = false;
            try { document.body.style.overflow = ''; } catch (e) { /* noop */ }
        }
    }
}
