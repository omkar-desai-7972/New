import { LightningElement, track } from 'lwc';
import { NavigationMixin }        from 'lightning/navigation';
import { CurrentPageReference }   from 'lightning/navigation';
import { wire }                   from 'lwc';
import communityBasePath          from '@salesforce/community/basePath';
import getPropertyDetail from '@salesforce/apex/PropertyDetailController.getPropertyDetail';

export default class PropertyDetail extends NavigationMixin(LightningElement) {

    @track detail       = null;
    @track isLoading    = true;
    @track isLoaded     = false;
    @track hasError     = false;
    @track errorMessage = '';

    propertyId = null;

    @wire(CurrentPageReference)
    setPageRef(pageRef) {
        if (pageRef && pageRef.state) {
            this.propertyId = pageRef.state.propertyId;
            if (this.propertyId) {
                this.loadDetail();
            }
        }
    }

    connectedCallback() {
        // Also try URL params directly
        const params = new URLSearchParams(window.location.search);
        const pid = params.get('propertyId');
        if (pid && !this.propertyId) {
            this.propertyId = pid;
            this.loadDetail();
        }
    }

    loadDetail() {
        this.isLoading = true;
        this.isLoaded  = false;
        this.hasError  = false;

        getPropertyDetail({ propertyId: this.propertyId })
            .then(data => {
                this.detail    = data;
                this.isLoading = false;
                this.isLoaded  = true;
            })
            .catch(error => {
                this.isLoading    = false;
                this.hasError     = true;
                this.errorMessage = this.extractError(error);
            });
    }

    // ─── Derived ───
    get wardLabel() { return 'Ward ' + this.detail?.wardNumber; }

    get assessmentsTitle() { return 'Assessments (' + (this.detail?.assessments?.length || 0) + ')'; }
    get paymentsTitle()    { return 'Payments ('    + (this.detail?.payments?.length    || 0) + ')'; }
    get casesTitle()       { return 'Cases ('       + (this.detail?.cases?.length       || 0) + ')'; }

    get hasAssessments() { return this.detail?.assessments?.length > 0; }
    get hasPayments()    { return this.detail?.payments?.length > 0; }
    get hasCases()       { return this.detail?.cases?.length > 0; }

    // Enriched rows with nicely formatted ₹ amounts
    get assessmentRows() {
        return (this.detail?.assessments || []).map(a => ({
            ...a,
            annualTaxFmt: this.formatCurrency(a.annualTax)
        }));
    }

    get paymentRows() {
        return (this.detail?.payments || []).map(p => ({
            ...p,
            baseAmountFmt: this.formatCurrency(p.baseAmount),
            taxAmountFmt:  this.formatCurrency(p.taxAmount),
            discountFmt:   this.formatCurrency(p.discountAmount),
            penaltyFmt:    this.formatCurrency(p.penaltyAmount)
        }));
    }

    get propertyInfo() {
        const d = this.detail || {};
        return [
            { key: 'id',    label: 'Property ID',       value: d.propertyName },
            { key: 'door',  label: 'Door Number',       value: d.doorNumber },
            { key: 'addr',  label: 'Address',           value: d.propertyAddress },
            { key: 'type',  label: 'Property Type',     value: d.propertyType },
            { key: 'zone',  label: 'Zone',              value: d.zone },
            { key: 'ward',  label: 'Ward Number',       value: d.wardNumber },
            { key: 'area',  label: 'Built-Up Area',     value: this.formattedArea + ' sq.ft.' },
            { key: 'cyear', label: 'Construction Year', value: d.constructionYear },
            { key: 'reg',   label: 'Registration Date', value: this.formattedRegDate },
            { key: 'status',label: 'Status',            value: d.propertyStatus }
        ];
    }

    get formattedTaxDue()  { return this.formatCurrency(this.detail?.totalTaxDue); }
    get formattedTaxPaid() { return this.formatCurrency(this.detail?.totalTaxPaid); }

    get formattedArea() {
        const v = this.detail?.builtUpArea;
        if (v == null) return '—';
        return Number(v).toLocaleString('en-IN');
    }

    get formattedRegDate() {
        const d = this.detail?.registrationDate;
        if (!d) return '—';
        return new Date(d).toLocaleDateString('en-IN', {
            day: '2-digit', month: 'short', year: 'numeric'
        });
    }

    // ─── Navigation ───
    handleBack() {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: { name: 'Home' }
        });
    }

    // Open the Cases & Grievances page and auto-start a new case pre-linked to
    // this property. Navigates to the exact community URL (/s/cases-and-grievances).
    handleRaiseCase() {
        const base = communityBasePath || '';
        const url = `${base}/cases-and-grievances?propertyId=${encodeURIComponent(this.propertyId || '')}&newCase=1`;
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: { url }
        });
    }

    // ─── Helpers ───
    formatCurrency(value) {
        if (value == null) return '₹0';
        return '₹' + Number(value).toLocaleString('en-IN', { maximumFractionDigits: 0 });
    }

    extractError(error) {
        if (error?.body?.message) return error.body.message;
        if (error?.message)       return error.message;
        return 'An unexpected error occurred.';
    }
}