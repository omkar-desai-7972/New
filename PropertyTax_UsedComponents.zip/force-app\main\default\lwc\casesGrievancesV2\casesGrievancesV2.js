import { LightningElement, track, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import { refreshApex } from '@salesforce/apex';

import getCaseSummary   from '@salesforce/apex/CitizenCaseController.getCaseSummary';
import getMyCases       from '@salesforce/apex/CitizenCaseController.getMyCases';
import createCase       from '@salesforce/apex/CitizenCaseController.createCase';
import getMyProperties  from '@salesforce/apex/CitizenCaseController.getMyPropertiesForCase';

const TYPE_FILTERS = [
    { label: 'All types',          value: 'All' },
    { label: 'Tax dispute',        value: 'Tax dispute' },
    { label: 'Payment issue',      value: 'Payment issue' },
    { label: 'Property correction',value: 'Property correction' },
    { label: 'Registration help',  value: 'Registration help' },
    { label: 'General inquiry',    value: 'General inquiry' }
];

const PRIORITY_OPTIONS = [
    { label: 'Low',    value: 'Low'    },
    { label: 'Medium', value: 'Medium' },
    { label: 'High',   value: 'High'   }
];

export default class CasesGrievancesV2 extends LightningElement {

    @track summary = {};
    @track cases   = [];
    @track activeFilter = 'All';
    @track searchTerm   = '';
    @track debouncedSearch = '';
    @track summaryLoaded = false;
    @track casesLoaded   = false;
    @track showCreateModal = false;
    @track creating = false;
    @track createError = null;
    @track listError = null;

    // Inline detail view
    @track selectedCaseId = null;

    // New case form
    @track formSubject     = '';
    @track formType        = 'Tax dispute';
    @track formPriority    = 'Medium';
    @track formDescription = '';
    @track formPropertyId  = '';

    // Property loading state
    @track myProperties      = [];
    @track propertiesLoaded  = false;
    @track propertiesError   = null;

    _searchTimer;
    _wiredCasesResult;
    _wiredSummaryResult;
    _autoOpened = false;

    // Arriving from the Property Detail "Raise a case" button: open the create
    // modal automatically, pre-linked to the property that was passed in.
    @wire(CurrentPageReference)
    handlePageRef(ref) {
        const state = ref?.state;
        if (!state || this._autoOpened) return;
        if (state.newCase === '1' || state.c__newCase === '1') {
            this._autoOpened = true;
            this.openCreate();
            const pid = state.propertyId || state.c__propertyId || '';
            if (pid) this.formPropertyId = pid;
        }
    }

    @wire(getCaseSummary)
    wiredSummary(result) {
        this._wiredSummaryResult = result;
        if (result.data) {
            this.summary = result.data;
            this.summaryLoaded = true;
        } else if (result.error) {
            this.summaryLoaded = true;
            console.error('Summary error', result.error);
        }
    }

    @wire(getMyProperties)
    wiredProperties({ data, error }) {
        if (data) {
            this.myProperties = data;
            this.propertiesLoaded = true;
            this.propertiesError = null;
        } else if (error) {
            this.propertiesLoaded = true;
            this.propertiesError =
                error?.body?.message ||
                'Could not load your properties.';
            console.error('Property load error:', error);
        }
    }

    @wire(getMyCases, { typeFilter: '$activeFilter', searchTerm: '$debouncedSearch' })
    wiredCases(result) {
        this._wiredCasesResult = result;
        if (result.data) {
            this.cases = result.data.map(c => this._enrich(c));
            this.casesLoaded = true;
            this.listError = null;
        } else if (result.error) {
            this.cases = [];
            this.casesLoaded = true;
            this.listError = result.error?.body?.message || 'Could not load cases.';
            console.error('Cases load error', result.error);
        }
    }

    // ── View state ──────────────────────────────────────────
    get showDetail() { return !!this.selectedCaseId; }
    get showList()   { return !this.selectedCaseId; }

    // ── Derived ─────────────────────────────────────────────
    get propertyOptions() {
        const opts = [{ label: '— No specific property —', value: '' }];
        for (const p of this.myProperties) {
            const addr = p.propertyAddress ? ' · ' + this._short(p.propertyAddress) : '';
            opts.push({
                label: (p.propertyName || 'Property') + addr,
                value: p.propertyId
            });
        }
        return opts;
    }
    get hasProperties()    { return this.myProperties && this.myProperties.length > 0; }
    get propertiesEmpty()  { return this.propertiesLoaded && !this.hasProperties && !this.propertiesError; }
    get propertiesLoading(){ return !this.propertiesLoaded; }

    get typeFilters() {
        return TYPE_FILTERS.map(f => ({
            ...f,
            cssClass: f.value === this.activeFilter ? 'tchip tchip-active' : 'tchip'
        }));
    }
    get priorityOptions() { return PRIORITY_OPTIONS; }
    get typeOptions()     { return TYPE_FILTERS.filter(f => f.value !== 'All'); }
    get hasCases()        { return this.cases?.length > 0; }
    get totalCount()      { return this.summary?.total ?? 0; }
    get openCount()       { return this.summary?.open ?? 0; }
    get resolvedCount()   { return this.summary?.resolved ?? 0; }
    get escalatedCount()  { return this.summary?.escalated ?? 0; }
    get skeletonItems()   { return [1,2,3,4]; }
    get canSubmit() {
        return this.formSubject?.trim().length > 0 &&
               this.formDescription?.trim().length > 0 &&
               !this.creating;
    }

    // ── Handlers ────────────────────────────────────────────
    handleFilter(e) {
        this.activeFilter = e.currentTarget.dataset.value;
        this.casesLoaded  = false;
    }

    handleSearch(e) {
        this.searchTerm = e.target.value;
        clearTimeout(this._searchTimer);
        this._searchTimer = setTimeout(() => {
            this.debouncedSearch = this.searchTerm;
        }, 320);
    }

    // Open the case inline instead of navigating to a separate page
    handleCaseClick(e) {
        this.selectedCaseId = e.currentTarget.dataset.id;
    }

    // Return to the list and refresh counts/badges (in case of replies, etc.)
    async handleBackToList() {
        this.selectedCaseId = null;
        await refreshApex(this._wiredSummaryResult);
        await refreshApex(this._wiredCasesResult);
    }

    openCreate() {
        this.showCreateModal = true;
        this.createError = null;
        this.formSubject     = '';
        this.formDescription = '';
        this.formType        = 'Tax dispute';
        this.formPriority    = 'Medium';
        this.formPropertyId  = '';
    }
    closeCreate() { this.showCreateModal = false; }
    stopProp(e)   { e.stopPropagation(); }

    onSubjectChange(e)  { this.formSubject     = e.target.value; }
    onTypeChange(e)     { this.formType        = e.detail.value; }
    onPriorityChange(e) { this.formPriority    = e.detail.value; }
    onPropertyChange(e) { this.formPropertyId  = e.detail.value; }
    onDescChange(e)     { this.formDescription = e.target.value; }

    async submitCase() {
        if (!this.canSubmit) return;
        this.creating = true; this.createError = null;
        try {
            const caseId = await createCase({
                subject:     this.formSubject,
                description: this.formDescription,
                type:        this.formType,
                priority:    this.formPriority,
                propertyId:  this.formPropertyId || null
            });
            this.creating = false;
            this.showCreateModal = false;
            await refreshApex(this._wiredSummaryResult);
            await refreshApex(this._wiredCasesResult);
            // Open the freshly filed case inline
            this.selectedCaseId = caseId;
        } catch (e) {
            this.creating = false;
            this.createError = e?.body?.message || 'Could not raise the case. Please try again.';
        }
    }

    // ── Enrichment ──────────────────────────────────────────
    _enrich(c) {
        const status = c.status?.toLowerCase() || '';
        let badge = { label: c.status, cls: 'cbadge cbadge-open' };
        if (c.isEscalated)                     badge = { label: 'Escalated',   cls: 'cbadge cbadge-escalated' };
        else if (c.isClosed)                   badge = { label: 'Resolved',    cls: 'cbadge cbadge-resolved' };
        else if (status.includes('progress'))  badge = { label: 'In progress', cls: 'cbadge cbadge-progress' };
        else if (status === 'new')             badge = { label: 'New',         cls: 'cbadge cbadge-new' };

        const created = c.createdDate ? new Date(c.createdDate) : null;
        const createdFmt = created
            ? created.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
            : '';

        return {
            ...c,
            badge,
            createdFmt,
            linkedLine: c.propertyName
                ? `Regarding: ${c.propertyName}${c.propertyAddress ? ' · ' + this._short(c.propertyAddress) : ''}`
                : 'Not linked to a property',
            linkedClass: c.propertyName ? 'cgcard-linked cgcard-linked-active' : 'cgcard-linked',
            filedLine: createdFmt ? `Filed ${createdFmt}` : '',
            replyLine: c.replyCount === 1 ? '1 reply' : `${c.replyCount} replies`,
            cardClass: c.isEscalated ? 'cgrid-card cgrid-escalated' : 'cgrid-card'
        };
    }

    _short(s) { return s && s.length > 50 ? s.slice(0, 47) + '…' : s; }
}