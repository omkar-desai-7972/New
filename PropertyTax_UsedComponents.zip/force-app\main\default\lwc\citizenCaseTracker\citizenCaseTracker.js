import { LightningElement, api, track, wire } from 'lwc';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CurrentPageReference } from 'lightning/navigation';

import getCaseDetail   from '@salesforce/apex/CitizenCaseController.getCaseDetail';
import getCaseComments from '@salesforce/apex/CitizenCaseController.getCaseComments';
import addReply        from '@salesforce/apex/CitizenCaseController.addReply';

export default class CitizenCaseTracker extends LightningElement {

    @api caseId;            // optional override when embedded in another component
    _pageCaseId;            // caseId read from the URL (?caseId=...)

    @track caseData    = null;
    @track thread      = [];
    @track detailLoaded = false;
    @track threadLoaded = false;
    @track replyText   = '';
    @track sending     = false;
    @track errorMsg    = null;

    _wiredDetail;
    _wiredThread;

    // Reads the caseId the list component passes via state: { caseId }
    @wire(CurrentPageReference)
    capturePageRef(pageRef) {
        const fromUrl = pageRef?.state?.caseId || pageRef?.state?.recordId;
        if (fromUrl) this._pageCaseId = fromUrl;
    }

    // What the wires actually use: explicit @api wins, else the URL value
    get effectiveCaseId() {
        return this.caseId || this._pageCaseId;
    }

    @wire(getCaseDetail, { caseId: '$effectiveCaseId' })
    wiredDetail(result) {
        this._wiredDetail = result;
        if (result.data) {
            this.caseData = this._enrich(result.data);
            this.detailLoaded = true;
        } else if (result.error) {
            this.detailLoaded = true;
            this.errorMsg = result.error?.body?.message || 'Could not load this case.';
        }
    }

    @wire(getCaseComments, { caseId: '$effectiveCaseId' })
    wiredThread(result) {
        this._wiredThread = result;
        if (result.data) {
            this.thread = result.data.map(c => this._enrichComment(c));
            this.threadLoaded = true;
        } else if (result.error) {
            this.threadLoaded = true;
        }
    }

    // ── Getters ────────────────────────────────────────────────

    get hasCase()   { return this.detailLoaded && this.caseData; }
    get hasThread() { return this.thread?.length > 0; }
    get isClosed()  { return this.caseData?.isClosed; }
    get canSend()   { return this.replyText?.trim().length > 0 && !this.sending; }

    /** Status path: Filed -> In review -> Resolved, with done/current/todo state. */
    get steps() {
        const c = this.caseData || {};
        const closed = c.isClosed;
        const working = !closed; // anything not closed is "in review" from citizen POV
        return [
            { key: 'filed',    label: 'Filed',     icon: 'utility:check',
              cls: this._stepCls('done') },
            { key: 'review',   label: 'In review', icon: 'utility:search',
              cls: this._stepCls(closed ? 'done' : 'current') },
            { key: 'resolved', label: 'Resolved',  icon: 'utility:success',
              cls: this._stepCls(closed ? 'current' : 'todo') }
        ];
    }
    _stepCls(state) { return `step step-${state}`; }

    get connectorAfterFiled()  { return this.caseData?.isClosed ? 'conn conn-done' : 'conn conn-done'; }
    get connectorAfterReview() { return this.caseData?.isClosed ? 'conn conn-done' : 'conn conn-todo'; }

    // ── Actions ────────────────────────────────────────────────

    onReplyChange(e) { this.replyText = e.target.value; }

    async sendReply() {
        if (!this.canSend) return;
        this.sending = true; this.errorMsg = null;
        try {
            await addReply({ caseId: this.effectiveCaseId, body: this.replyText });
            this.replyText = '';
            this.sending = false;
            await refreshApex(this._wiredThread);
            await refreshApex(this._wiredDetail);
            this._toast('Reply sent', 'Your reply was added to the case.', 'success');
        } catch (e) {
            this.sending = false;
            this.errorMsg = e?.body?.message || 'Could not send your reply.';
        }
    }

    dismissError() { this.errorMsg = null; }

    // ── Enrichment ─────────────────────────────────────────────

    _enrich(c) {
        let statusLabel = c.isEscalated ? 'Escalated'
                        : c.isClosed    ? 'Resolved'
                        : (c.status === 'New' ? 'Received' : 'In review');
        let statusCls = c.isEscalated ? 'pill pill-warning'
                      : c.isClosed    ? 'pill pill-success'
                      : 'pill pill-info';
        return {
            ...c,
            statusLabel,
            statusCls,
            handledByLabel: c.handledBy || 'Being assigned',
            propertyLabel: c.propertyName
                ? `${c.propertyName}${c.propertyAddress ? ' · ' + this._short(c.propertyAddress) : ''}`
                : 'Not linked to a property',
            createdFmt:  this._fmtDate(c.createdDate),
            updatedFmt:  this._fmtDate(c.lastModifiedDate || c.createdDate),
            resolvedFmt: c.closedDate ? this._fmtDate(c.closedDate) : null
        };
    }

    _enrichComment(c) {
        return {
            ...c,
            createdFmt: this._fmtDateTime(c.createdDate),
            wrapClass:  c.isCitizen ? 'msg msg-citizen' : 'msg msg-officer',
            roleLabel:  c.isCitizen ? 'You' : c.authorName,
            initials:   this._initials(c.isCitizen ? 'You' : c.authorName)
        };
    }

    _fmtDate(d) {
        if (!d) return '';
        return new Date(d).toLocaleDateString('en-IN', {
            day: 'numeric', month: 'short', year: 'numeric'
        });
    }
    _fmtDateTime(d) {
        if (!d) return '';
        return new Date(d).toLocaleString('en-IN', {
            day: 'numeric', month: 'short', hour: 'numeric',
            minute: '2-digit', hour12: true
        });
    }
    _short(s) { return s && s.length > 48 ? s.slice(0, 45) + '…' : s; }
    _initials(name) {
        if (!name) return '?';
        const parts = name.trim().split(/\s+/).filter(Boolean);
        if (parts.length === 0) return '?';
        return (parts[0][0] + (parts[1]?.[0] || '')).toUpperCase();
    }

    _toast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}