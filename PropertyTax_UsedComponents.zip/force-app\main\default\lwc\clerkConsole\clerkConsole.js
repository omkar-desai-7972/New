import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import getStats             from '@salesforce/apex/ClerkConsoleController.getStats';
import getPendingProperties from '@salesforce/apex/ClerkConsoleController.getPendingProperties';
import getMyCases           from '@salesforce/apex/ClerkConsoleController.getMyCases';
import approveProperty      from '@salesforce/apex/ClerkConsoleController.approveProperty';
import rejectProperty       from '@salesforce/apex/ClerkConsoleController.rejectProperty';

/**
 * clerkConsole
 * ------------
 * Internal staff dashboard. Shows property/case stats, the pending-approval
 * queue (Approve -> Tax Officer / Reject), and the user's open cases.
 * Imperative Apex (cacheable=false) so every load and every action shows fresh
 * data. Reused by Clerk and Tax Officer (the case list is owner/queue based).
 */
export default class ClerkConsole extends NavigationMixin(LightningElement) {

    @track stats      = {};
    @track pending    = [];
    @track cases      = [];
    @track isLoading  = true;
    @track errorMsg   = null;
    @track busyId     = null;   // property id mid-approve/reject (disables its buttons)

    connectedCallback() {
        this.loadAll();
    }

    async loadAll() {
        this.isLoading = true;
        this.errorMsg  = null;
        try {
            const [stats, pending, cases] = await Promise.all([
                getStats(), getPendingProperties(), getMyCases()
            ]);
            this.stats   = stats;
            this.pending = pending.map(p => this.decorateProperty(p));
            this.cases   = cases.map(c => this.decorateCase(c));
        } catch (e) {
            this.errorMsg = this.msg(e);
        } finally {
            this.isLoading = false;
        }
    }

    // ── Derived ───────────────────────────────────────────────────────────
    get hasPending() { return this.pending && this.pending.length > 0; }
    get hasCases()   { return this.cases && this.cases.length > 0; }

    // ── Actions ─────────────────────────────────────────────────────────────
    async handleApprove(event) {
        const propertyId = event.currentTarget.dataset.id;
        await this.runAction(propertyId, approveProperty, 'Approved & sent forward');
    }

    async handleReject(event) {
        const propertyId = event.currentTarget.dataset.id;
        await this.runAction(propertyId, rejectProperty, 'Property registration rejected');
    }

    async runAction(propertyId, action, successMsg) {
        const row = this.pending.find(p => p.propertyId === propertyId);
        if (!row || !row.workitemId) {
            this.toast('Could not complete', 'No pending approval found for this record.', 'error');
            return;
        }
        this.busyId = propertyId;
        // Reactively disable just this row's buttons and clear any prior error.
        this.pending = this.pending.map(p =>
            p.propertyId === propertyId ? { ...p, isBusy: true, actionError: null } : p);
        try {
            await action({ workitemId: row.workitemId });
            this.toast('Done', successMsg, 'success');
            await this.loadAll();          // refresh counts + lists
        } catch (e) {
            // Keep the row visible and show exactly why it failed (e.g. a
            // validation rule: "Area must be greater than 0 sq.ft.").
            const reason = this.msg(e);
            this.toast('Could not complete', reason, 'error');
            this.pending = this.pending.map(p =>
                p.propertyId === propertyId ? { ...p, isBusy: false, actionError: reason } : p);
        } finally {
            this.busyId = null;
        }
    }

    handleOpenProperty(event) {
        this.navigateToRecord(event.currentTarget.dataset.id, 'Property__c');
    }

    handleOpenCase(event) {
        this.navigateToRecord(event.currentTarget.dataset.id, 'Case');
    }

    handleRefresh() { this.loadAll(); }

    // ── Internals ───────────────────────────────────────────────────────────
    navigateToRecord(recordId, objectApiName) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: { recordId, objectApiName, actionName: 'view' }
        });
    }

    decorateProperty(p) {
        return {
            ...p,
            wardLabel:   p.wardNumber != null ? 'Ward ' + p.wardNumber : '',
            areaLabel:   p.builtUpArea != null ? p.builtUpArea + ' sq.ft' : '',
            dateLabel:   this.fmtDate(p.registrationDate),
            isBusy:      this.busyId === p.propertyId,
            actionError: null
        };
    }

    decorateCase(c) {
        const cls = c.isEscalated ? 'pill pill-escalated'
                  : c.priority === 'High' ? 'pill pill-high'
                  : 'pill pill-normal';
        return { ...c, pillClass: cls, dateLabel: this.fmtDate(c.createdDate) };
    }

    fmtDate(d) {
        if (!d) return '';
        return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    toast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }

    msg(e) {
        return (e && e.body && e.body.message) ? e.body.message : 'Something went wrong.';
    }
}
